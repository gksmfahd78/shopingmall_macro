﻿namespace macro
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.signup_name_text_box = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.se_button = new System.Windows.Forms.Button();
            this.link_button = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.signup_id_text_box = new System.Windows.Forms.TextBox();
            this.signup_pw_text_box = new System.Windows.Forms.TextBox();
            this.signup_pw2_text_box = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.signup_stop_check_box = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.signup_info_check_box = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.signup_sigunup_button = new System.Windows.Forms.Button();
            this.signup_cancle_button = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // signup_name_text_box
            // 
            this.signup_name_text_box.Location = new System.Drawing.Point(123, 106);
            this.signup_name_text_box.Name = "signup_name_text_box";
            this.signup_name_text_box.Size = new System.Drawing.Size(249, 21);
            this.signup_name_text_box.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "이름";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.se_button);
            this.groupBox1.Controls.Add(this.link_button);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.signup_id_text_box);
            this.groupBox1.Controls.Add(this.signup_pw_text_box);
            this.groupBox1.Controls.Add(this.signup_pw2_text_box);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.signup_stop_check_box);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.signup_info_check_box);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.signup_name_text_box);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(395, 199);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "회원가입";
            // 
            // se_button
            // 
            this.se_button.Location = new System.Drawing.Point(334, 160);
            this.se_button.Name = "se_button";
            this.se_button.Size = new System.Drawing.Size(38, 19);
            this.se_button.TabIndex = 17;
            this.se_button.Text = "확인";
            this.se_button.UseVisualStyleBackColor = true;
            this.se_button.Click += new System.EventHandler(this.se_button_Click);
            // 
            // link_button
            // 
            this.link_button.Location = new System.Drawing.Point(334, 137);
            this.link_button.Name = "link_button";
            this.link_button.Size = new System.Drawing.Size(38, 19);
            this.link_button.TabIndex = 16;
            this.link_button.Text = "확인";
            this.link_button.UseVisualStyleBackColor = true;
            this.link_button.Click += new System.EventHandler(this.link_button_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 82);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 12);
            this.label8.TabIndex = 15;
            this.label8.Text = "비밀번호 확인";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 55);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 14;
            this.label7.Text = "비밀번호";
            // 
            // signup_id_text_box
            // 
            this.signup_id_text_box.Location = new System.Drawing.Point(123, 25);
            this.signup_id_text_box.Name = "signup_id_text_box";
            this.signup_id_text_box.Size = new System.Drawing.Size(249, 21);
            this.signup_id_text_box.TabIndex = 1;
            // 
            // signup_pw_text_box
            // 
            this.signup_pw_text_box.Location = new System.Drawing.Point(123, 52);
            this.signup_pw_text_box.Name = "signup_pw_text_box";
            this.signup_pw_text_box.PasswordChar = '*';
            this.signup_pw_text_box.Size = new System.Drawing.Size(249, 21);
            this.signup_pw_text_box.TabIndex = 2;
            // 
            // signup_pw2_text_box
            // 
            this.signup_pw2_text_box.Location = new System.Drawing.Point(123, 79);
            this.signup_pw2_text_box.Name = "signup_pw2_text_box";
            this.signup_pw2_text_box.PasswordChar = '*';
            this.signup_pw2_text_box.Size = new System.Drawing.Size(249, 21);
            this.signup_pw2_text_box.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 10;
            this.label6.Text = "아이디";
            // 
            // signup_stop_check_box
            // 
            this.signup_stop_check_box.AutoSize = true;
            this.signup_stop_check_box.Location = new System.Drawing.Point(288, 162);
            this.signup_stop_check_box.Name = "signup_stop_check_box";
            this.signup_stop_check_box.Size = new System.Drawing.Size(48, 16);
            this.signup_stop_check_box.TabIndex = 8;
            this.signup_stop_check_box.Text = "동의";
            this.signup_stop_check_box.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 168);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "되팔램/채굴 금지";
            // 
            // signup_info_check_box
            // 
            this.signup_info_check_box.AutoSize = true;
            this.signup_info_check_box.Location = new System.Drawing.Point(288, 140);
            this.signup_info_check_box.Name = "signup_info_check_box";
            this.signup_info_check_box.Size = new System.Drawing.Size(48, 16);
            this.signup_info_check_box.TabIndex = 7;
            this.signup_info_check_box.Text = "동의";
            this.signup_info_check_box.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "개인 정보 활용";
            // 
            // signup_sigunup_button
            // 
            this.signup_sigunup_button.Location = new System.Drawing.Point(336, 217);
            this.signup_sigunup_button.Name = "signup_sigunup_button";
            this.signup_sigunup_button.Size = new System.Drawing.Size(75, 23);
            this.signup_sigunup_button.TabIndex = 3;
            this.signup_sigunup_button.Text = "가입하기";
            this.signup_sigunup_button.UseVisualStyleBackColor = true;
            this.signup_sigunup_button.Click += new System.EventHandler(this.signup_sigunup_button_Click);
            // 
            // signup_cancle_button
            // 
            this.signup_cancle_button.Location = new System.Drawing.Point(255, 217);
            this.signup_cancle_button.Name = "signup_cancle_button";
            this.signup_cancle_button.Size = new System.Drawing.Size(75, 23);
            this.signup_cancle_button.TabIndex = 4;
            this.signup_cancle_button.Text = "취소";
            this.signup_cancle_button.UseVisualStyleBackColor = true;
            this.signup_cancle_button.Click += new System.EventHandler(this.signup_cancle_button_Click);
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.ClientSize = new System.Drawing.Size(418, 250);
            this.Controls.Add(this.signup_cancle_button);
            this.Controls.Add(this.signup_sigunup_button);
            this.Controls.Add(this.groupBox1);
            this.Name = "SignUp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "회원가입";
            this.Load += new System.EventHandler(this.SignUp_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox signup_name_text_box;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox signup_id_text_box;
        private System.Windows.Forms.TextBox signup_pw_text_box;
        private System.Windows.Forms.TextBox signup_pw2_text_box;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox signup_stop_check_box;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox signup_info_check_box;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button signup_sigunup_button;
        private System.Windows.Forms.Button signup_cancle_button;
        private System.Windows.Forms.Button se_button;
        private System.Windows.Forms.Button link_button;
    }
}